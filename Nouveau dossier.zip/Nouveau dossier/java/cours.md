Les chaînes de caractères peuvent se concaténer à l’aide de l’opérateur +, ou à l'aide de la méthode concat. Ces deux concaténations ne sont pas équivalentes lorsque l'opérande de droite vaut null.
Les instances peuvent ne pas être créées explicitement String s = "abc" ; au lieu de String s = new String("abc") ;

### Comparaisons
int compareTo(Object o)

Compare une chaîne de caractère à un autre objet. Renvoie une valeur <0 ==0 ou > 0

int compareTo(String anotherString)

Compare une chaîne de caractère à un autre objet. Renvoie une valeur <0 ==0 ou > 0. La comparaison est une comparaison lexicographique.

int compareToIgnoreCase(String str)

Compare une chaîne de caractère à un autre objet. Renvoie une valeur <0 ==0 ou > 0. La comparaison est une comparaison lexicographique, ignorant la casse.

boolean equals(Object anObject)

Compare la chaîne a un objet et retourne true en cas d’égalité et false sinon

boolean equalsIgnoreCase(Object anObject)

Compare la chaîne a un objet et retourne true en cas d’égalité et false sinon ( on ignore la casse)

boolean regionMatches(boolean ignoreCase, int toffset, String other, int ooffset, int len)

Teste l’égalité de deux parties de chaînes

boolean regionMatches(int toffset, String other, int ooffset, int len)

Teste l’égalité de deux parties de chaînes

Caractère et sous-chaîne
char charAt(int i)

Retourne le caractère à l’indice spécifié en paramètre.

String substring(int d)

Sous-chaîne depuis d jusqu’à la fin

String substring(int d, int f)

Sous-chaîne depuis d jusqu’au caractère d’indice f non inclus.

boolean startsWith(String prefix)

Renvoie true si prefix est un préfixe de la chaîne

boolean startsWith(String prefix, int i)

Renvoie true si prefix est un préfixe de la chaîne à partir de i.

boolean endsWith(String suffix)

Retourne true si suffix est un suffixe de la chaîne

### Conversions
String toLowerCase()

Retourne une chaîne égale à la chaîne convertie en minuscules.

String toLowerCase(Locale locale)

Retourne une chaîne égale à la chaîne convertie en minuscules.

String toString()

Retourne une chaîne égale à la chaîne

String toUpperCase()

Retourne une chaîne égale à la chaîne convertie en majuscules.

String toUpperCase(Locale locale)

Retourne une chaîne égale à la chaîne convertie en majuscules.

String trim()

Retourne une chaîne égale à la chaîne sans les espaces de début et de fin.

String replace(char ac, char nc)

Retourne une chaîne ou tous les ac ont été remplacé par des nc. S’il n’y a pas de remplacement, la chaîne elle-même est retournée.

### Recherche
int indexOf(int ch)

Retourne l’indice de la première occurrence du caractère

int indexOf(int ch, int fromIndex)

Retourne l’indice de la première occurrence du caractère à partir de fromIndex

int indexOf(String str)

Retourne l’indice de la première occurrence de la chaîne

int indexOf(String str, int fromIndex)

Retourne l’indice de la première occurrence de la chaîne à partir de fromIndex

int lastIndexOf(int ch)

Retourne l’indice de la dernière occurrence du caractère

int lastIndexOf(int ch, int fromIndex)

Retourne l’indice de la dernière occurrence du caractère à partir de fromIndex

int lastIndexOf(String str)

Retourne l’indice de la dernière occurrence de la chaîne

int lastIndexOf(String str, int fromIndex)

Retourne l’indice de la dernière occurrence de la chaîne à partir de fromIndex

La classe String maintient un pool de chaînes de caractères. Dans ce pool sont représentées :

les chaînes littérales "..."

les chaînes pour lesquelles on a fait un appel à le méthode native intern() C'est pour celà que la comparaison avec l'opérateur == fonctionne pour les chaines de caractères du pool !

String s1 = "abcde";
String s2 = "abcde";
String s3 = new String (s2);
String s4 = s3.intern();
System.out.println(s1==s2);// true les deux sont dans le pool
System.out.println(s1==s3);// false
System.out.println(s1==s4);// true les deux sont dans le pool
### StringBuffer, StringBuilder
Les StringBuffer sont utilisés pour compiler l’opérateur + de la classe String. Par exemple : > x = "a" + 4 + "c"

est compilé en : > x = newStringBuffer().append("a").append(4).append("c").toString()

----------------------------------------------------------------------------------------------------------------------
### Les Classes
Une classe peut être comparée à une structure de données qui, lorsque nous le remplissons, nous donne un objet ayant la forme d'une structure qu'on peux utiliser à l'infinie.

Pour pouvoir manipuler des objets, il est essentiel de définir des classes, c'est-à-dire définir la structure d'un objet. Cette définition avec Java se fait de la manière suivante :

public class NomDeLaClasse { 
    // Instructions permettant de définir la classe 
}
Remarques :

Par convention le nom d'une classe commence par une majuscule

Une classe public doit obligatoirement être codée dans un fichier .java qui porte son nom, en revanche on peut coder autant de classes "non-public" que l'on veut dans le même fichier.

Déclaration des données membres
Jusqu'ici notre classe est vide (elle est toutefois syntaxiquement correcte), c'est-à-dire qu'elle ne contient ni données (appelées données membres) ni traitements (fonctions appelées méthodes). En réalité elle hérite malgré tout des propriétés de la classe Object qui est commune à toutes les classes.

Les données membres sont des variables stockées au sein d'une classe. Elles doivent être précédées de leur type et (éventuellement) d'une étiquette précisant leur portée, c'est-à-dire les classes ayant le droit d'y accéder.

Ces étiquettes sont au nombre de trois :

public
private
protected
Déclaration des méthodes
Les données membres permettent de conserver des informations relatives à la classe, tandis que les méthodes représentent les traitements qu'il est possible de réaliser avec les objets instanciés de la classe. Elles permettent en particulier de garantir l'intégrité de ces données membres (généralement private) en effectuant sur celles-ci uniquement des traitements corrects.

La définition d'une méthode se fait en définissant le prototype et le corps de la fonction à l'intérieur de la classe en une opération.

Voici donc la syntaxe d'une classe avec des méthodes :

public class NomDeLaClasse { 
    // Instructions permettant de définir les méthodes de la classe 
    Etiquettes TypeDeValeurRenvoyée nomDeLaMethode(TypeDuParametre1 nomDuParametre1, TypeDuParametre2 nomDuParametre2) { 
        // Instructions du corps de la méthode 
    }// fin méthode 
}// fin class
Remarques :

Par convention le nom d'une méthode commence par une minuscule

L'encapsulation concerne également les méthode de manipulation des données membres. On peut donc placer l'une des trois étiquettes (public, protected, private) devant les méthodes.


refferences du cours : https://gayerie.dev/epsi-b3-java/langage_java