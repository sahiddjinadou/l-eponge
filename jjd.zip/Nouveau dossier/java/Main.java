public class Main {
    public static void main(String[] args) {
        long myint = 2147483648L;
        System.out.println(myint);

        String name = JOptionPane.showInputDialog("Entrez votre nom");
        JOptionPane.showMessageDialog(null, name);
    }
}