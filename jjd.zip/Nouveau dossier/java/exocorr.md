
Correction Tableau
Exercice 1
import java.util.Scanner;

public class Exercice1{

    public static void main(String[] args){

        Scanner scanner = new Scanner(System.in);

        System.out.println("Merci de saisir le nombre d'étudiants :");
        int nombreEtudiant = (int) scanner.nextFloat();     

        // 1- création de notre tab d'étudiants
        float [] listEtudiant = new float[nombreEtudiant];

        // saisir les notes
        // [ , , , ] vide => remplir
        for (int i = 0; i < listEtudiant.length ; i++ ) {
            System.out.println("Merci de saisir la note de l'étudiant n°" + (i+1) +" / " + listEtudiant.length + " il vous reste à saisir " + (listEtudiant.length - i) +" etudiant (s)");
            listEtudiant[i] = scanner.nextFloat();
        }// end for 
        // tableau rempli avec les notes des étudiants :D

        // 2- somme des notes
        int somme = 0;
        for (int i = 0; i < listEtudiant.length ; i++ ) {
            somme += listEtudiant[i]; // la meme que (somme = somme + listEtudiant[i];)
        }
        // somme va contenir le total des notes

        // 3- calculer la moyen
        float moyen = (float) somme / listEtudiant.length; // note globale / nombre d'étudiants

        System.out.println("La note moyenne est : "+ moyen);



    }// end main

} // end class
Exercice 2
import java.util.List;
import java.util.ArrayList;

public class ExerciceTab1{

    public static void main(String[] args){


        // 1- création list dynamique
        List<String> listNom = new ArrayList<>();

        // 2- ajout des élements dans notre list
        // nomList.add(valeur)
        listNom.add("CISSE");
        listNom.add("MACHI");
        listNom.add("ROCHE");
        listNom.add("VALLERY");


        // 3- afficher l'ensemble des valeurs
        for(int i = 0; i < listNom.size(); i++){
            System.out.println(listNom.get(i)); // .get(position) commance par 0
        }// end for

    }// end main

}// end class
Exercice 3
import java.util.List;  
public class ExerciceTabRemove{  

    public static void main(String[] args){  

        List<Integer> list = new java.util.ArrayList<Integer>(); // création d'une list dynamique  

 // ajouter des elements dans notre list  list.add(12);  
  list.add(12);  
  list.add(1);  
  list.add(112);  
  list.add(12);  
  list.add(123);  
  list.add(12);  
  list.add(12);  

  // supprimer la valeur 12 de mon tableau  (methode 1)  
 /*for(int i = 0; i < list.size() ; i++){ 
     System.out.println("position : i = " + i + " Valeur :"+ list.get(i));  
     if(list.get(i) == 12){ 
         System.out.println("   trouver 12 position : i = " + i); 
         list.remove(i); // remove(postion pas de valeur :D) 
         i--; // ou i = i -1; 
    } 
 }*/  
 // supprimer la valeur 12 de mon tableau  (methode 2)  for (int i = list.size()-1 ; i >= 0; i--){  
            if(list.get(i) == 12){  
                list.remove(i); // remove(postion pas de valeur :D)  
  }  
        }  

        System.out.println(list); // selement les tab dynamique  

  }// end main  

}// end class